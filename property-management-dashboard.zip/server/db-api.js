const express = require("express")
const cors = require("cors")
const path = require("path")
const { Pool } = require("pg")
require("dotenv").config()

const app = express()
const PORT = process.env.PORT || 3000

// Database connection
let pool

// Initialize database connection
function initializeDatabase() {
  if (!process.env.DATABASE_URL) {
    console.error("❌ DATABASE_URL environment variable is required")
    console.log("Please set up your DATABASE_URL environment variable:")
    console.log("Example: DATABASE_URL=postgresql://username:password@localhost:5432/rental_tracker")
    console.log("")
    console.log("✅ Other environment variables detected:")
    console.log(`- RESEND_API_KEY: ${process.env.RESEND_API_KEY ? "✅ Configured" : "❌ Missing"}`)
    console.log(`- SIGNWELL_API_KEY: ${process.env.SIGNWELL_API_KEY ? "✅ Configured" : "❌ Missing"}`)

    // For development, we can use a simple in-memory fallback
    console.log("\n🔄 Starting in development mode with in-memory storage...")
    return false
  }

  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  })

  console.log("✅ Database connection initialized")
  return true
}

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.static(path.join(__dirname, "../")))

// Development mode in-memory storage
const devProperties = []
let devNextId = 1
let useDatabase = false

// Initialize database or fallback to development mode
useDatabase = initializeDatabase()

// Health check endpoint
app.get("/api/health", async (req, res) => {
  try {
    if (useDatabase) {
      await pool.query("SELECT 1")
      res.json({
        status: "healthy",
        timestamp: new Date().toISOString(),
        database: "connected",
        mode: "production",
      })
    } else {
      res.json({
        status: "healthy",
        timestamp: new Date().toISOString(),
        database: "development",
        mode: "development",
      })
    }
  } catch (error) {
    res.status(500).json({ error: "Database connection failed" })
  }
})

// Properties API endpoints
app.get("/api/properties", async (req, res) => {
  try {
    if (useDatabase) {
      const result = await pool.query("SELECT * FROM properties ORDER BY created_at DESC")
      res.json(result.rows)
    } else {
      // Development mode
      res.json(devProperties)
    }
  } catch (error) {
    console.error("Error fetching properties:", error)
    res.status(500).json({ error: error.message })
  }
})

app.post("/api/properties", async (req, res) => {
  try {
    const { name, address, monthly_rent, bedrooms, bathrooms, sqft } = req.body

    if (!name || !address || !monthly_rent) {
      return res.status(400).json({ error: "Name, address, and monthly rent are required" })
    }

    if (useDatabase) {
      const result = await pool.query(
        "INSERT INTO properties (name, address, monthly_rent, bedrooms, bathrooms, sqft) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
        [name, address, monthly_rent, bedrooms || 1, bathrooms || 1, sqft],
      )
      res.status(201).json(result.rows[0])
    } else {
      // Development mode
      const property = {
        id: devNextId++,
        name,
        address,
        monthly_rent: Number.parseFloat(monthly_rent),
        bedrooms: bedrooms || 1,
        bathrooms: bathrooms || 1,
        sqft: sqft || null,
        photos: [],
        created_at: new Date().toISOString(),
      }
      devProperties.push(property)
      res.status(201).json(property)
    }
  } catch (error) {
    console.error("Error creating property:", error)
    res.status(500).json({ error: error.message })
  }
})

app.put("/api/properties/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { name, address, monthly_rent, bedrooms, bathrooms, sqft } = req.body

    if (!name || !address || !monthly_rent) {
      return res.status(400).json({ error: "Name, address, and monthly rent are required" })
    }

    if (useDatabase) {
      const result = await pool.query(
        "UPDATE properties SET name = $1, address = $2, monthly_rent = $3, bedrooms = $4, bathrooms = $5, sqft = $6 WHERE id = $7 RETURNING *",
        [name, address, monthly_rent, bedrooms, bathrooms, sqft, id],
      )

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Property not found" })
      }

      res.json(result.rows[0])
    } else {
      // Development mode
      const index = devProperties.findIndex((p) => p.id === Number.parseInt(id))
      if (index === -1) {
        return res.status(404).json({ error: "Property not found" })
      }

      devProperties[index] = {
        ...devProperties[index],
        name,
        address,
        monthly_rent: Number.parseFloat(monthly_rent),
        bedrooms,
        bathrooms,
        sqft,
      }
      res.json(devProperties[index])
    }
  } catch (error) {
    console.error("Error updating property:", error)
    res.status(500).json({ error: error.message })
  }
})

app.delete("/api/properties/:id", async (req, res) => {
  try {
    const { id } = req.params

    if (useDatabase) {
      const result = await pool.query("DELETE FROM properties WHERE id = $1 RETURNING *", [id])

      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Property not found" })
      }

      res.json({ message: "Property deleted successfully" })
    } else {
      // Development mode
      const index = devProperties.findIndex((p) => p.id === Number.parseInt(id))
      if (index === -1) {
        return res.status(404).json({ error: "Property not found" })
      }

      devProperties.splice(index, 1)
      res.json({ message: "Property deleted successfully" })
    }
  } catch (error) {
    console.error("Error deleting property:", error)
    res.status(500).json({ error: error.message })
  }
})

// Email notification endpoints
app.post("/api/notifications/test", async (req, res) => {
  try {
    const NotificationService = require("./notifications")
    const notificationService = new NotificationService()

    const { email, type = "test" } = req.body

    if (!email) {
      return res.status(400).json({ error: "Email address is required" })
    }

    const result = await notificationService.sendEmail(
      email,
      "Test Email from Rental Dashboard",
      `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #8b5cf6;">🎉 Email Service Test</h2>
          <p>Congratulations! Your email service is working correctly.</p>
          <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>Test Type:</strong> ${type}</p>
            <p><strong>Timestamp:</strong> ${new Date().toISOString()}</p>
            <p><strong>API Keys Configured:</strong></p>
            <ul>
              <li>✅ RESEND_API_KEY: Configured</li>
              <li>${process.env.SIGNWELL_API_KEY ? "✅" : "❌"} SIGNWELL_API_KEY: ${process.env.SIGNWELL_API_KEY ? "Configured" : "Not configured"}</li>
            </ul>
          </div>
          <p style="color: #6b7280; font-size: 14px;">
            This test email was sent from your Rental Property Dashboard.
          </p>
        </div>
      `,
    )

    res.json(result)
  } catch (error) {
    console.error("Error sending test email:", error)
    res.status(500).json({ error: error.message })
  }
})

// Property notification endpoint
app.post("/api/properties/:id/notify", async (req, res) => {
  try {
    const { id } = req.params
    const { type, email } = req.body

    // Get property data
    let property
    if (useDatabase) {
      const result = await pool.query("SELECT * FROM properties WHERE id = $1", [id])
      if (result.rows.length === 0) {
        return res.status(404).json({ error: "Property not found" })
      }
      property = result.rows[0]
    } else {
      property = devProperties.find((p) => p.id === Number.parseInt(id))
      if (!property) {
        return res.status(404).json({ error: "Property not found" })
      }
    }

    const NotificationService = require("./notifications")
    const notificationService = new NotificationService()

    const result = await notificationService.sendPropertyNotification(
      property,
      type || "updated",
      email || "manager@yourdomain.com",
    )

    res.json(result)
  } catch (error) {
    console.error("Error sending property notification:", error)
    res.status(500).json({ error: error.message })
  }
})

// Serve frontend files
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../index.html"))
})

app.get("/dashboard", (req, res) => {
  res.sendFile(path.join(__dirname, "../dashboard.html"))
})

// Create database tables if they don't exist
async function createTables() {
  if (!useDatabase) {
    console.log("📝 Running in development mode - no database tables needed")
    return
  }

  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS properties (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        address TEXT NOT NULL,
        monthly_rent NUMERIC(10, 2) NOT NULL,
        bedrooms INTEGER DEFAULT 1,
        bathrooms INTEGER DEFAULT 1,
        sqft INTEGER,
        photos JSON DEFAULT '[]',
        created_at TIMESTAMP DEFAULT NOW()
      )
    `)
    console.log("✅ Database tables created/verified")
  } catch (error) {
    console.error("❌ Error creating tables:", error)
  }
}

// Start server
app.listen(PORT, async () => {
  await createTables()
  console.log(`🚀 Server running on http://localhost:${PORT}`)
  console.log(`📊 Dashboard available at http://localhost:${PORT}/dashboard`)
  console.log("")
  console.log("📋 Setup checklist:")
  console.log("✅ Server started")
  console.log(useDatabase ? "✅ Database connected" : "🔄 Development mode (in-memory storage)")
  console.log(process.env.RESEND_API_KEY ? "✅ Resend API key configured" : "⚠️  RESEND_API_KEY not set")
  console.log(process.env.SIGNWELL_API_KEY ? "✅ SignWell API key configured" : "⚠️  SIGNWELL_API_KEY not set")

  if (!useDatabase) {
    console.log("")
    console.log("💡 To use a real database, set the DATABASE_URL environment variable:")
    console.log("   DATABASE_URL=postgresql://username:password@localhost:5432/rental_tracker")
  }
})
