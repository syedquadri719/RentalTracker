/**
 * Task scheduler for recurring operations
 */

class SchedulerService {
  constructor() {
    this.tasks = new Map()
    this.intervals = new Map()
  }

  addTask(name, fn, intervalMs) {
    this.tasks.set(name, fn)

    const interval = setInterval(async () => {
      try {
        await fn()
        console.log(`✅ Task '${name}' completed successfully`)
      } catch (error) {
        console.error(`❌ Task '${name}' failed:`, error)
      }
    }, intervalMs)

    this.intervals.set(name, interval)
    console.log(`📅 Scheduled task '${name}' to run every ${intervalMs}ms`)
  }

  removeTask(name) {
    const interval = this.intervals.get(name)
    if (interval) {
      clearInterval(interval)
      this.intervals.delete(name)
      this.tasks.delete(name)
      console.log(`🗑️  Removed scheduled task '${name}'`)
    }
  }

  async runTask(name) {
    const task = this.tasks.get(name)
    if (task) {
      try {
        await task()
        console.log(`✅ Manual task '${name}' completed`)
      } catch (error) {
        console.error(`❌ Manual task '${name}' failed:`, error)
      }
    }
  }

  listTasks() {
    return Array.from(this.tasks.keys())
  }
}

// Example scheduled tasks
function initializeScheduledTasks(scheduler) {
  // Daily backup task
  scheduler.addTask(
    "daily-backup",
    async () => {
      console.log("Running daily backup...")
      // Backup logic would go here
    },
    24 * 60 * 60 * 1000,
  ) // 24 hours

  // Weekly reports
  scheduler.addTask(
    "weekly-report",
    async () => {
      console.log("Generating weekly report...")
      // Report generation logic would go here
    },
    7 * 24 * 60 * 60 * 1000,
  ) // 7 days
}

module.exports = { SchedulerService, initializeScheduledTasks }
