/**
 * File storage utilities
 */

const fs = require("fs").promises
const path = require("path")

class StorageService {
  constructor(baseDir = "./uploads") {
    this.baseDir = baseDir
    this.ensureDirectoryExists()
  }

  async ensureDirectoryExists() {
    try {
      await fs.mkdir(this.baseDir, { recursive: true })
    } catch (error) {
      console.error("Error creating storage directory:", error)
    }
  }

  async saveFile(filename, data) {
    try {
      const filePath = path.join(this.baseDir, filename)
      await fs.writeFile(filePath, data)
      return filePath
    } catch (error) {
      throw new Error(`Failed to save file: ${error.message}`)
    }
  }

  async deleteFile(filename) {
    try {
      const filePath = path.join(this.baseDir, filename)
      await fs.unlink(filePath)
      return true
    } catch (error) {
      throw new Error(`Failed to delete file: ${error.message}`)
    }
  }

  async getFile(filename) {
    try {
      const filePath = path.join(this.baseDir, filename)
      return await fs.readFile(filePath)
    } catch (error) {
      throw new Error(`Failed to read file: ${error.message}`)
    }
  }
}

module.exports = StorageService
