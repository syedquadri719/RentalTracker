/**
 * Simplified API for basic operations
 */

const express = require("express")
const app = express()

app.use(express.json())

// Simple in-memory storage for development
const properties = []
let nextId = 1

// Get all properties
app.get("/api/properties", (req, res) => {
  res.json(properties)
})

// Create property
app.post("/api/properties", (req, res) => {
  const property = {
    id: nextId++,
    ...req.body,
    created_at: new Date().toISOString(),
  }
  properties.push(property)
  res.status(201).json(property)
})

// Update property
app.put("/api/properties/:id", (req, res) => {
  const id = Number.parseInt(req.params.id)
  const index = properties.findIndex((p) => p.id === id)

  if (index === -1) {
    return res.status(404).json({ error: "Property not found" })
  }

  properties[index] = { ...properties[index], ...req.body }
  res.json(properties[index])
})

// Delete property
app.delete("/api/properties/:id", (req, res) => {
  const id = Number.parseInt(req.params.id)
  const index = properties.findIndex((p) => p.id === id)

  if (index === -1) {
    return res.status(404).json({ error: "Property not found" })
  }

  properties.splice(index, 1)
  res.json({ message: "Property deleted successfully" })
})

module.exports = app
