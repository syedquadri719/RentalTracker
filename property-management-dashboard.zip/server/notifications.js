/**
 * Notification service using Resend
 */

const { Resend } = require("resend")

class NotificationService {
  constructor() {
    if (process.env.RESEND_API_KEY) {
      this.resend = new Resend(process.env.RESEND_API_KEY)
      console.log("✅ Resend email service initialized")
    } else {
      console.warn("⚠️  RESEND_API_KEY not configured - email notifications disabled")
    }
  }

  async sendEmail(to, subject, html, from = "noreply@yourdomain.com") {
    if (!this.resend) {
      console.log("📧 Email would be sent (service not configured):", { to, subject })
      return { success: false, message: "Email service not configured" }
    }

    try {
      const result = await this.resend.emails.send({
        from,
        to,
        subject,
        html,
      })

      console.log("✅ Email sent successfully:", { to, subject, id: result.id })
      return { success: true, data: result }
    } catch (error) {
      console.error("❌ Email send error:", error)
      return { success: false, error: error.message }
    }
  }

  async sendPropertyNotification(property, type, recipientEmail = "manager@yourdomain.com") {
    const subject = `Property ${type}: ${property.name}`
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #8b5cf6;">Property ${type}</h2>
        <div style="background: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Name:</strong> ${property.name}</p>
          <p><strong>Address:</strong> ${property.address}</p>
          <p><strong>Monthly Rent:</strong> $${Number.parseFloat(property.monthly_rent).toLocaleString()}</p>
          <p><strong>Bedrooms:</strong> ${property.bedrooms || "N/A"}</p>
          <p><strong>Bathrooms:</strong> ${property.bathrooms || "N/A"}</p>
          <p><strong>Square Feet:</strong> ${property.sqft || "N/A"}</p>
        </div>
        <p style="color: #6b7280; font-size: 14px;">
          This notification was sent from your Rental Property Dashboard.
        </p>
      </div>
    `

    return await this.sendEmail(recipientEmail, subject, html)
  }

  async sendMaintenanceAlert(property, maintenanceRequest, recipientEmail = "maintenance@yourdomain.com") {
    const subject = `Maintenance Request: ${property.name}`
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #ef4444;">Maintenance Request</h2>
        <div style="background: #fef2f2; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ef4444;">
          <p><strong>Property:</strong> ${property.name}</p>
          <p><strong>Address:</strong> ${property.address}</p>
          <p><strong>Issue:</strong> ${maintenanceRequest.description}</p>
          <p><strong>Priority:</strong> ${maintenanceRequest.priority || "Normal"}</p>
          <p><strong>Reported:</strong> ${new Date().toLocaleDateString()}</p>
        </div>
        <p style="color: #6b7280; font-size: 14px;">
          Please address this maintenance request as soon as possible.
        </p>
      </div>
    `

    return await this.sendEmail(recipientEmail, subject, html)
  }

  async sendRentReminder(tenant, property, recipientEmail) {
    const subject = `Rent Reminder: ${property.name}`
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #8b5cf6;">Rent Payment Reminder</h2>
        <div style="background: #f0f9ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p>Dear ${tenant.name},</p>
          <p>This is a friendly reminder that your rent payment is due.</p>
          <p><strong>Property:</strong> ${property.name}</p>
          <p><strong>Address:</strong> ${property.address}</p>
          <p><strong>Amount Due:</strong> $${Number.parseFloat(property.monthly_rent).toLocaleString()}</p>
          <p><strong>Due Date:</strong> ${new Date().toLocaleDateString()}</p>
        </div>
        <p>Please contact us if you have any questions.</p>
        <p style="color: #6b7280; font-size: 14px;">
          Best regards,<br>
          Property Management Team
        </p>
      </div>
    `

    return await this.sendEmail(recipientEmail, subject, html)
  }
}

module.exports = NotificationService
