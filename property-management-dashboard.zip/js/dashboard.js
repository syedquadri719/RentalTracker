// Dashboard functionality
let currentSection = "overview"

// Show/hide sections
function showSection(sectionName) {
  // Hide all sections
  document.querySelectorAll(".section").forEach((section) => {
    section.classList.add("hidden")
  })

  // Show selected section
  document.getElementById(sectionName).classList.remove("hidden")
  currentSection = sectionName

  // Load section data
  loadSectionData(sectionName)
}

// Load data for specific sections
async function loadSectionData(section) {
  switch (section) {
    case "overview":
      await loadOverviewData()
      break
    case "properties":
      await loadProperties()
      break
    case "tenants":
      await loadTenants()
      break
    default:
      break
  }
}

// Load overview statistics
async function loadOverviewData() {
  try {
    const response = await fetch("/api/overview")
    const data = await response.json()

    document.getElementById("total-properties").textContent = data.totalProperties || 0
    document.getElementById("active-tenants").textContent = data.activeTenants || 0
    document.getElementById("pending-maintenance").textContent = data.pendingMaintenance || 0
    document.getElementById("monthly-revenue").textContent = `$${data.monthlyRevenue || 0}`
  } catch (error) {
    console.error("Error loading overview data:", error)
  }
}

// Load properties
async function loadProperties() {
  try {
    const response = await fetch("/api/properties")
    const data = await response.json()

    const tableBody = document.getElementById("properties-table")
    tableBody.innerHTML = ""

    if (data.properties && data.properties.length > 0) {
      data.properties.forEach((property) => {
        const row = createPropertyRow(property)
        tableBody.appendChild(row)
      })
    } else {
      tableBody.innerHTML =
        '<tr><td colspan="5" class="px-6 py-4 text-center text-gray-500">No properties found</td></tr>'
    }
  } catch (error) {
    console.error("Error loading properties:", error)
  }
}

// Create property table row
function createPropertyRow(property) {
  const row = document.createElement("tr")
  row.innerHTML = `
        <td class="px-6 py-4 whitespace-nowrap">
            <div class="text-sm font-medium text-gray-900">${property.name || "Unnamed Property"}</div>
        </td>
        <td class="px-6 py-4 whitespace-nowrap">
            <div class="text-sm text-gray-900">${property.address || "No address"}</div>
        </td>
        <td class="px-6 py-4 whitespace-nowrap">
            <div class="text-sm text-gray-900">${property.type || "Unknown"}</div>
        </td>
        <td class="px-6 py-4 whitespace-nowrap">
            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(property.status)}">
                ${property.status || "Unknown"}
            </span>
        </td>
        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
            <button class="text-blue-600 hover:text-blue-900 mr-3" onclick="editProperty(${property.id})">Edit</button>
            <button class="text-red-600 hover:text-red-900" onclick="deleteProperty(${property.id})">Delete</button>
        </td>
    `
  return row
}

// Get status color classes
function getStatusColor(status) {
  switch (status?.toLowerCase()) {
    case "occupied":
      return "bg-green-100 text-green-800"
    case "vacant":
      return "bg-yellow-100 text-yellow-800"
    case "maintenance":
      return "bg-red-100 text-red-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

// Load tenants
async function loadTenants() {
  try {
    const response = await fetch("/api/tenants")
    const data = await response.json()

    const tableBody = document.getElementById("tenants-table")
    tableBody.innerHTML = ""

    if (data.tenants && data.tenants.length > 0) {
      data.tenants.forEach((tenant) => {
        const row = createTenantRow(tenant)
        tableBody.appendChild(row)
      })
    } else {
      tableBody.innerHTML = '<tr><td colspan="5" class="px-6 py-4 text-center text-gray-500">No tenants found</td></tr>'
    }
  } catch (error) {
    console.error("Error loading tenants:", error)
  }
}

// Create tenant table row
function createTenantRow(tenant) {
  const row = document.createElement("tr")
  row.innerHTML = `
        <td class="px-6 py-4 whitespace-nowrap">
            <div class="text-sm font-medium text-gray-900">${tenant.name || "Unnamed Tenant"}</div>
        </td>
        <td class="px-6 py-4 whitespace-nowrap">
            <div class="text-sm text-gray-900">${tenant.property || "No property"}</div>
        </td>
        <td class="px-6 py-4 whitespace-nowrap">
            <div class="text-sm text-gray-900">${tenant.contact || "No contact"}</div>
        </td>
        <td class="px-6 py-4 whitespace-nowrap">
            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getTenantStatusColor(tenant.status)}">
                ${tenant.status || "Unknown"}
            </span>
        </td>
        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
            <button class="text-blue-600 hover:text-blue-900 mr-3" onclick="editTenant(${tenant.id})">Edit</button>
            <button class="text-red-600 hover:text-red-900" onclick="deleteTenant(${tenant.id})">Delete</button>
        </td>
    `
  return row
}

// Get tenant status color classes
function getTenantStatusColor(status) {
  switch (status?.toLowerCase()) {
    case "active":
      return "bg-green-100 text-green-800"
    case "inactive":
      return "bg-red-100 text-red-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

// Modal functions (placeholders)
function openAddPropertyModal() {
  alert("Add Property modal would open here")
}

function editProperty(id) {
  alert(`Edit property ${id}`)
}

function deleteProperty(id) {
  if (confirm("Are you sure you want to delete this property?")) {
    alert(`Delete property ${id}`)
  }
}

function openAddTenantModal() {
  alert("Add Tenant modal would open here")
}

function editTenant(id) {
  alert(`Edit tenant ${id}`)
}

function deleteTenant(id) {
  if (confirm("Are you sure you want to delete this tenant?")) {
    alert(`Delete tenant ${id}`)
  }
}

// Initialize dashboard
document.addEventListener("DOMContentLoaded", () => {
  loadSectionData("overview")
})
