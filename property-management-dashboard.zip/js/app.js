/**
 * Main application initialization and global functionality
 */

// Global state
let currentEditingProperty = null

// Declare necessary variables
const checkDatabaseConnection = async () => {
  // Placeholder for database connection check
  console.log("Checking database connection...")
  // Simulate a database connection check
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve()
    }, 1000)
  })
}

const PropertyService = {
  getAll: async () => {
    // Placeholder for fetching all properties
    console.log("Fetching all properties...")
    // Simulate fetching properties
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve([
          {
            id: 1,
            name: "Property 1",
            address: "123 Main St",
            bedrooms: 2,
            bathrooms: 1,
            sqft: 1000,
            monthly_rent: 1500,
            status: "occupied",
          },
          {
            id: 2,
            name: "Property 2",
            address: "456 Elm St",
            bedrooms: 3,
            bathrooms: 2,
            sqft: 1500,
            monthly_rent: 2000,
            status: "available",
          },
        ])
      }, 1000)
    })
  },
  update: async (id, data) => {
    // Placeholder for updating a property
    console.log(`Updating property with id ${id}...`, data)
    // Simulate updating a property
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve()
      }, 1000)
    })
  },
  create: async (data) => {
    // Placeholder for creating a property
    console.log("Creating a new property...", data)
    // Simulate creating a property
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve()
      }, 1000)
    })
  },
  delete: async (id) => {
    // Placeholder for deleting a property
    console.log(`Deleting property with id ${id}...`)
    // Simulate deleting a property
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve()
      }, 1000)
    })
  },
}

/**
 * Initialize the application
 */
document.addEventListener("DOMContentLoaded", async () => {
  console.log("Initializing Property Management Dashboard...")

  try {
    // Check database connection
    await checkDatabaseConnection()

    // Load initial data
    await loadDashboardData()

    // Initialize event listeners
    initializeEventListeners()

    console.log("Dashboard initialized successfully")
  } catch (error) {
    console.error("Failed to initialize dashboard:", error)
    showToast("Failed to connect to database. Please check your connection.", "error")
  }
})

/**
 * Load dashboard data
 */
async function loadDashboardData() {
  try {
    showLoadingIndicator(true)

    // Load properties
    const properties = await PropertyService.getAll()

    // Update stats
    updateDashboardStats(properties)

    // Render properties
    renderProperties(properties)

    showLoadingIndicator(false)
  } catch (error) {
    console.error("Error loading dashboard data:", error)
    showLoadingIndicator(false)
    showToast("Failed to load properties", "error")
  }
}

/**
 * Update dashboard statistics
 */
function updateDashboardStats(properties) {
  const totalProperties = properties.length
  const monthlyRevenue = properties.reduce((sum, prop) => sum + Number.parseFloat(prop.monthly_rent || 0), 0)
  const occupiedUnits = properties.filter((prop) => prop.status === "occupied").length
  const maintenanceRequests = 0 // Placeholder for future implementation

  document.getElementById("total-properties").textContent = totalProperties
  document.getElementById("monthly-revenue").textContent = `$${monthlyRevenue.toLocaleString()}`
  document.getElementById("occupied-units").textContent = occupiedUnits
  document.getElementById("maintenance-requests").textContent = maintenanceRequests
}

/**
 * Render properties in the grid
 */
function renderProperties(properties) {
  const container = document.getElementById("properties-container")
  const emptyState = document.getElementById("empty-state")

  if (properties.length === 0) {
    container.innerHTML = ""
    emptyState.classList.remove("hidden")
    return
  }

  emptyState.classList.add("hidden")
  container.innerHTML = properties.map((property) => createPropertyCard(property)).join("")
}

/**
 * Create a property card HTML
 */
function createPropertyCard(property) {
  return `
        <div class="property-card bg-white rounded-lg shadow card-shadow p-6">
            <div class="flex justify-between items-start mb-4">
                <h3 class="text-lg font-semibold text-gray-900">${property.name}</h3>
                <div class="flex space-x-2">
                    <button onclick="editProperty(${property.id})" class="text-blue-600 hover:text-blue-800">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button onclick="deleteProperty(${property.id})" class="text-red-600 hover:text-red-800">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            <p class="text-gray-600 text-sm mb-3">${property.address}</p>
            <div class="grid grid-cols-2 gap-4 text-sm text-gray-600 mb-4">
                <div><i class="fas fa-bed mr-1"></i> ${property.bedrooms || 0} bed</div>
                <div><i class="fas fa-bath mr-1"></i> ${property.bathrooms || 0} bath</div>
                <div><i class="fas fa-ruler-combined mr-1"></i> ${property.sqft || "N/A"} sqft</div>
                <div><i class="fas fa-dollar-sign mr-1"></i> $${Number.parseFloat(property.monthly_rent || 0).toLocaleString()}/mo</div>
            </div>
            <div class="flex justify-between items-center">
                <span class="px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(property.status)}">
                    ${property.status || "Available"}
                </span>
                <button onclick="viewProperty(${property.id})" class="text-purple-600 hover:text-purple-800 text-sm font-medium">
                    View Details
                </button>
            </div>
        </div>
    `
}

/**
 * Get status color classes
 */
function getStatusColor(status) {
  switch (status?.toLowerCase()) {
    case "occupied":
      return "bg-green-100 text-green-800"
    case "available":
      return "bg-blue-100 text-blue-800"
    case "maintenance":
      return "bg-yellow-100 text-yellow-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

/**
 * Initialize event listeners
 */
function initializeEventListeners() {
  // Add property button
  document.getElementById("add-property-btn").addEventListener("click", openAddPropertyModal)

  // Modal cancel button
  document.getElementById("cancel-btn").addEventListener("click", closePropertyModal)

  // Property form submission
  document.getElementById("property-form").addEventListener("submit", handlePropertySubmit)

  // Close modal when clicking outside
  document.getElementById("property-modal").addEventListener("click", function (e) {
    if (e.target === this) {
      closePropertyModal()
    }
  })

  // Empty state add button
  document.querySelector("#empty-state button").addEventListener("click", openAddPropertyModal)

  // Email test button
  document.getElementById("send-test-email").addEventListener("click", sendTestEmail)
}

/**
 * Send test email
 */
async function sendTestEmail() {
  const emailInput = document.getElementById("test-email")
  const button = document.getElementById("send-test-email")
  const resultDiv = document.getElementById("email-test-result")

  const email = emailInput.value.trim()

  if (!email) {
    showToast("Please enter an email address", "error")
    return
  }

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email)) {
    showToast("Please enter a valid email address", "error")
    return
  }

  try {
    // Update button state
    button.disabled = true
    button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Sending...'

    const response = await fetch("/api/notifications/test", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, type: "dashboard-test" }),
    })

    const result = await response.json()

    if (result.success) {
      showToast("Test email sent successfully! Check your inbox.", "success")
      resultDiv.innerHTML = `
        <div class="bg-green-50 border border-green-200 rounded-md p-4">
          <div class="flex">
            <i class="fas fa-check-circle text-green-400 mr-2 mt-0.5"></i>
            <div>
              <h4 class="text-sm font-medium text-green-800">Email sent successfully!</h4>
              <p class="text-sm text-green-700 mt-1">Check your inbox at ${email}</p>
            </div>
          </div>
        </div>
      `
      resultDiv.classList.remove("hidden")
    } else {
      throw new Error(result.message || result.error || "Failed to send email")
    }
  } catch (error) {
    console.error("Error sending test email:", error)
    showToast(`Failed to send test email: ${error.message}`, "error")
    resultDiv.innerHTML = `
      <div class="bg-red-50 border border-red-200 rounded-md p-4">
        <div class="flex">
          <i class="fas fa-exclamation-circle text-red-400 mr-2 mt-0.5"></i>
          <div>
            <h4 class="text-sm font-medium text-red-800">Email failed to send</h4>
            <p class="text-sm text-red-700 mt-1">${error.message}</p>
          </div>
        </div>
      </div>
    `
    resultDiv.classList.remove("hidden")
  } finally {
    // Reset button state
    button.disabled = false
    button.innerHTML = '<i class="fas fa-envelope mr-2"></i>Send Test Email'
  }
}

/**
 * Open add property modal
 */
function openAddPropertyModal() {
  currentEditingProperty = null
  document.getElementById("modal-title").textContent = "Add Property"
  document.getElementById("submit-text").textContent = "Add Property"
  document.getElementById("property-form").reset()
  document.getElementById("property-modal").classList.remove("hidden")
}

/**
 * Open edit property modal
 */
function editProperty(id) {
  // This would typically fetch the property data
  // For now, we'll implement a basic version
  currentEditingProperty = id
  document.getElementById("modal-title").textContent = "Edit Property"
  document.getElementById("submit-text").textContent = "Update Property"
  document.getElementById("property-modal").classList.remove("hidden")

  // TODO: Populate form with existing property data
}

/**
 * Close property modal
 */
function closePropertyModal() {
  document.getElementById("property-modal").classList.add("hidden")
  currentEditingProperty = null
}

/**
 * Handle property form submission
 */
async function handlePropertySubmit(e) {
  e.preventDefault()

  const formData = new FormData(e.target)
  const propertyData = Object.fromEntries(formData.entries())

  try {
    if (currentEditingProperty) {
      await PropertyService.update(currentEditingProperty, propertyData)
      showToast("Property updated successfully", "success")
    } else {
      await PropertyService.create(propertyData)
      showToast("Property added successfully", "success")
    }

    closePropertyModal()
    await loadDashboardData()
  } catch (error) {
    console.error("Error saving property:", error)
    showToast(error.message, "error")
  }
}

/**
 * Delete property
 */
async function deleteProperty(id) {
  if (!confirm("Are you sure you want to delete this property?")) {
    return
  }

  try {
    await PropertyService.delete(id)
    showToast("Property deleted successfully", "success")
    await loadDashboardData()
  } catch (error) {
    console.error("Error deleting property:", error)
    showToast(error.message, "error")
  }
}

/**
 * View property details
 */
function viewProperty(id) {
  // TODO: Implement property details view
  showToast("Property details view coming soon", "info")
}

/**
 * Show loading indicator
 */
function showLoadingIndicator(show) {
  const indicator = document.getElementById("loading-indicator")
  if (show) {
    indicator.classList.remove("hidden")
  } else {
    indicator.classList.add("hidden")
  }
}

/**
 * Show toast notification
 */
function showToast(message, type = "info") {
  const container = document.getElementById("toast-container")
  const toast = document.createElement("div")

  const bgColor =
    {
      success: "bg-green-500",
      error: "bg-red-500",
      warning: "bg-yellow-500",
      info: "bg-blue-500",
    }[type] || "bg-blue-500"

  toast.className = `${bgColor} text-white px-6 py-3 rounded-lg shadow-lg toast-enter`
  toast.innerHTML = `
        <div class="flex items-center justify-between">
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `

  container.appendChild(toast)

  // Auto remove after 5 seconds
  setTimeout(() => {
    if (toast.parentElement) {
      toast.classList.add("toast-exit")
      setTimeout(() => toast.remove(), 300)
    }
  }, 5000)
}
