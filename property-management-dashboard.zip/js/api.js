/**
 * API configuration and utilities
 */

// API base URL
const API_BASE_URL = window.location.origin + "/api"

/**
 * Make HTTP request to API
 */
async function apiRequest(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`
  const config = {
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
    ...options,
  }

  if (config.body && typeof config.body === "object") {
    config.body = JSON.stringify(config.body)
  }

  const response = await fetch(url, config)

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: "Request failed" }))
    throw new Error(errorData.error || `HTTP ${response.status}`)
  }

  return response.json()
}

/**
 * Database operations for properties using API
 */
const PropertyService = {
  /**
   * Fetch all properties from the database
   * @returns {Promise<Array>} Array of property objects
   */
  async getAll() {
    try {
      return await apiRequest("/properties")
    } catch (error) {
      console.error("Error fetching properties:", error)
      throw new Error(`Failed to fetch properties: ${error.message}`)
    }
  },

  /**
   * Create a new property
   * @param {Object} property - Property data to insert
   * @returns {Promise<Object>} Created property object
   */
  async create(property) {
    try {
      // Validate required fields
      if (!property.name || !property.address || !property.monthly_rent) {
        throw new Error("Name, address, and monthly rent are required")
      }

      // Ensure monthly_rent is a number
      const propertyData = {
        ...property,
        monthly_rent: Number.parseFloat(property.monthly_rent),
      }

      return await apiRequest("/properties", {
        method: "POST",
        body: propertyData,
      })
    } catch (error) {
      console.error("Error creating property:", error)
      throw new Error(`Failed to create property: ${error.message}`)
    }
  },

  /**
   * Update an existing property
   * @param {number} id - Property ID to update
   * @param {Object} updates - Property data to update
   * @returns {Promise<Object>} Updated property object
   */
  async update(id, updates) {
    try {
      // Validate required fields
      if (!updates.name || !updates.address || !updates.monthly_rent) {
        throw new Error("Name, address, and monthly rent are required")
      }

      // Ensure monthly_rent is a number
      const propertyData = {
        ...updates,
        monthly_rent: Number.parseFloat(updates.monthly_rent),
      }

      return await apiRequest(`/properties/${id}`, {
        method: "PUT",
        body: propertyData,
      })
    } catch (error) {
      console.error("Error updating property:", error)
      throw new Error(`Failed to update property: ${error.message}`)
    }
  },

  /**
   * Delete a property
   * @param {number} id - Property ID to delete
   * @returns {Promise<boolean>} Success status
   */
  async delete(id) {
    try {
      await apiRequest(`/properties/${id}`, {
        method: "DELETE",
      })
      return true
    } catch (error) {
      console.error("Error deleting property:", error)
      throw new Error(`Failed to delete property: ${error.message}`)
    }
  },
}

/**
 * Check API connection and health
 */
async function checkDatabaseConnection() {
  try {
    await apiRequest("/health")
    console.log("API connection successful")
    return true
  } catch (error) {
    console.error("API connection failed:", error)
    throw new Error("Unable to connect to the API server")
  }
}

// Export for use in other modules
window.PropertyService = PropertyService
window.checkDatabaseConnection = checkDatabaseConnection
