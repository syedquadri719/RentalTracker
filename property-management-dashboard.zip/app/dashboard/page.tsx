"use client"

import { useState, useEffect } from "react"
import {
  Home,
  DollarSign,
  Users,
  Wrench,
  Plus,
  Edit,
  Trash2,
  Eye,
  Bell,
  UserCircle,
  Bed,
  Bath,
  Square,
  Mail,
  Loader2,
  CheckCircle,
  XCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Property {
  id: number
  name: string
  address: string
  monthly_rent: number
  bedrooms: number
  bathrooms: number
  sqft?: number
  status: "occupied" | "available" | "maintenance"
  created_at: string
}

export default function Dashboard() {
  const [properties, setProperties] = useState<Property[]>([])
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [currentProperty, setCurrentProperty] = useState<Property | null>(null)
  const [testEmail, setTestEmail] = useState("")
  const [isEmailTesting, setIsEmailTesting] = useState(false)
  const [emailTestResult, setEmailTestResult] = useState<"success" | "error" | null>(null)
  const { toast } = useToast()

  // Sample data for demo
  useEffect(() => {
    const sampleProperties: Property[] = [
      {
        id: 1,
        name: "Sunset Apartments",
        address: "123 Main Street, Downtown",
        monthly_rent: 1500,
        bedrooms: 2,
        bathrooms: 1,
        sqft: 1000,
        status: "occupied",
        created_at: new Date().toISOString(),
      },
      {
        id: 2,
        name: "Oak View Townhouse",
        address: "456 Oak Avenue, Suburbs",
        monthly_rent: 2200,
        bedrooms: 3,
        bathrooms: 2.5,
        sqft: 1500,
        status: "available",
        created_at: new Date().toISOString(),
      },
      {
        id: 3,
        name: "City Center Loft",
        address: "789 Urban Plaza, City Center",
        monthly_rent: 1800,
        bedrooms: 1,
        bathrooms: 1,
        sqft: 800,
        status: "maintenance",
        created_at: new Date().toISOString(),
      },
      {
        id: 4,
        name: "Garden Villa",
        address: "321 Garden Lane, Westside",
        monthly_rent: 2800,
        bedrooms: 4,
        bathrooms: 3,
        sqft: 2200,
        status: "available",
        created_at: new Date().toISOString(),
      },
      {
        id: 5,
        name: "Riverside Condo",
        address: "555 River Drive, Waterfront",
        monthly_rent: 2100,
        bedrooms: 2,
        bathrooms: 2,
        sqft: 1200,
        status: "occupied",
        created_at: new Date().toISOString(),
      },
    ]
    setProperties(sampleProperties)
  }, [])

  const stats = {
    totalProperties: properties.length,
    monthlyRevenue: properties.reduce((sum, prop) => sum + prop.monthly_rent, 0),
    occupiedUnits: properties.filter((p) => p.status === "occupied").length,
    maintenanceRequests: properties.filter((p) => p.status === "maintenance").length,
  }

  const handleAddProperty = (formData: FormData) => {
    const newProperty: Property = {
      id: Date.now(),
      name: formData.get("name") as string,
      address: formData.get("address") as string,
      monthly_rent: Number(formData.get("monthly_rent")),
      bedrooms: Number(formData.get("bedrooms")) || 1,
      bathrooms: Number(formData.get("bathrooms")) || 1,
      sqft: Number(formData.get("sqft")) || undefined,
      status: (formData.get("status") as Property["status"]) || "available",
      created_at: new Date().toISOString(),
    }

    setProperties((prev) => [...prev, newProperty])
    setIsModalOpen(false)
    toast({
      title: "Success",
      description: "Property added successfully!",
    })
  }

  const handleEditProperty = (property: Property) => {
    setCurrentProperty(property)
    setIsModalOpen(true)
  }

  const handleUpdateProperty = (formData: FormData) => {
    if (!currentProperty) return

    const updatedProperty: Property = {
      ...currentProperty,
      name: formData.get("name") as string,
      address: formData.get("address") as string,
      monthly_rent: Number(formData.get("monthly_rent")),
      bedrooms: Number(formData.get("bedrooms")) || 1,
      bathrooms: Number(formData.get("bathrooms")) || 1,
      sqft: Number(formData.get("sqft")) || undefined,
      status: (formData.get("status") as Property["status"]) || "available",
    }

    setProperties((prev) => prev.map((p) => (p.id === currentProperty.id ? updatedProperty : p)))
    setIsModalOpen(false)
    setCurrentProperty(null)
    toast({
      title: "Success",
      description: "Property updated successfully!",
    })
  }

  const handleDeleteProperty = (id: number) => {
    if (confirm("Are you sure you want to delete this property?")) {
      setProperties((prev) => prev.filter((p) => p.id !== id))
      toast({
        title: "Success",
        description: "Property deleted successfully!",
      })
    }
  }

  const handleTestEmail = async () => {
    if (!testEmail) {
      toast({
        title: "Error",
        description: "Please enter an email address",
        variant: "destructive",
      })
      return
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(testEmail)) {
      toast({
        title: "Error",
        description: "Please enter a valid email address",
        variant: "destructive",
      })
      return
    }

    setIsEmailTesting(true)
    setEmailTestResult(null)

    // Simulate email sending with random success/failure
    setTimeout(() => {
      setIsEmailTesting(false)
      const success = Math.random() > 0.2 // 80% success rate for demo

      if (success) {
        setEmailTestResult("success")
        toast({
          title: "Email Sent Successfully!",
          description: `Test email sent to ${testEmail}. Check your inbox!`,
        })
      } else {
        setEmailTestResult("error")
        toast({
          title: "Email Failed",
          description: "Failed to send test email. Please check your API configuration.",
          variant: "destructive",
        })
      }
    }, 2000)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "occupied":
        return "bg-green-100 text-green-800 border-green-200"
      case "available":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "maintenance":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const PropertyForm = ({ property, onSubmit }: { property?: Property; onSubmit: (formData: FormData) => void }) => (
    <form action={onSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Property Name</Label>
        <Input id="name" name="name" defaultValue={property?.name} required placeholder="e.g., Sunset Apartments" />
      </div>
      <div>
        <Label htmlFor="address">Address</Label>
        <Textarea
          id="address"
          name="address"
          defaultValue={property?.address}
          required
          rows={2}
          placeholder="e.g., 123 Main Street, Downtown"
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="bedrooms">Bedrooms</Label>
          <Input
            id="bedrooms"
            name="bedrooms"
            type="number"
            min="0"
            defaultValue={property?.bedrooms || 1}
            placeholder="1"
          />
        </div>
        <div>
          <Label htmlFor="bathrooms">Bathrooms</Label>
          <Input
            id="bathrooms"
            name="bathrooms"
            type="number"
            min="0"
            step="0.5"
            defaultValue={property?.bathrooms || 1}
            placeholder="1"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="sqft">Square Feet</Label>
          <Input id="sqft" name="sqft" type="number" min="0" defaultValue={property?.sqft} placeholder="1000" />
        </div>
        <div>
          <Label htmlFor="monthly_rent">Monthly Rent ($)</Label>
          <Input
            id="monthly_rent"
            name="monthly_rent"
            type="number"
            min="0"
            step="0.01"
            defaultValue={property?.monthly_rent}
            required
            placeholder="1500"
          />
        </div>
      </div>
      <div>
        <Label htmlFor="status">Status</Label>
        <Select name="status" defaultValue={property?.status || "available"}>
          <SelectTrigger>
            <SelectValue placeholder="Select status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="available">Available</SelectItem>
            <SelectItem value="occupied">Occupied</SelectItem>
            <SelectItem value="maintenance">Maintenance</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex justify-end space-x-3 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => {
            setIsModalOpen(false)
            setCurrentProperty(null)
          }}
        >
          Cancel
        </Button>
        <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
          {property ? "Update Property" : "Add Property"}
        </Button>
      </div>
    </form>
  )

  return (
    <div className="bg-gray-100 min-h-screen">
      {/* Navigation */}
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Home className="text-purple-600 h-6 w-6 mr-3" />
              <h1 className="text-xl font-bold text-gray-800">Property Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <UserCircle className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto py-6 px-4">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Home className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Properties</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.totalProperties}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <DollarSign className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Monthly Revenue</p>
                  <p className="text-2xl font-bold text-gray-900">${stats.monthlyRevenue.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Occupied Units</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.occupiedUnits}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-2 bg-yellow-100 rounded-lg">
                  <Wrench className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Maintenance</p>
                  <p className="text-2xl font-bold text-gray-900">{stats.maintenanceRequests}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Properties Section */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Properties ({properties.length})</CardTitle>
              <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
                <DialogTrigger asChild>
                  <Button onClick={() => setCurrentProperty(null)} className="bg-purple-600 hover:bg-purple-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Property
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>{currentProperty ? "Edit Property" : "Add Property"}</DialogTitle>
                  </DialogHeader>
                  <PropertyForm
                    property={currentProperty || undefined}
                    onSubmit={currentProperty ? handleUpdateProperty : handleAddProperty}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {properties.map((property) => (
                <Card key={property.id} className="hover:shadow-lg transition-all duration-200 hover:-translate-y-1">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-lg font-semibold text-gray-900">{property.name}</h3>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" onClick={() => handleEditProperty(property)}>
                          <Edit className="h-4 w-4 text-blue-600" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDeleteProperty(property.id)}>
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">{property.address}</p>
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-600 mb-4">
                      <div className="flex items-center">
                        <Bed className="h-4 w-4 mr-1" />
                        {property.bedrooms} bed
                      </div>
                      <div className="flex items-center">
                        <Bath className="h-4 w-4 mr-1" />
                        {property.bathrooms} bath
                      </div>
                      <div className="flex items-center">
                        <Square className="h-4 w-4 mr-1" />
                        {property.sqft || "N/A"} sqft
                      </div>
                      <div className="flex items-center">
                        <DollarSign className="h-4 w-4 mr-1" />${property.monthly_rent.toLocaleString()}/mo
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <Badge className={getStatusColor(property.status)}>
                        {property.status.charAt(0).toUpperCase() + property.status.slice(1)}
                      </Badge>
                      <Button variant="ghost" size="sm" className="text-purple-600 hover:text-purple-800">
                        <Eye className="h-4 w-4 mr-1" />
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Email Test Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Mail className="h-5 w-5 mr-2" />
              Email Service Test
            </CardTitle>
            <p className="text-sm text-gray-600">Test your Resend API integration with property notifications</p>
          </CardHeader>
          <CardContent>
            <div className="max-w-md space-y-4">
              <div>
                <Label htmlFor="test-email">Test Email Address</Label>
                <Input
                  id="test-email"
                  type="email"
                  placeholder="your@email.com"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                />
              </div>
              <Button onClick={handleTestEmail} disabled={isEmailTesting} className="bg-green-600 hover:bg-green-700">
                {isEmailTesting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Mail className="h-4 w-4 mr-2" />
                    Send Test Email
                  </>
                )}
              </Button>

              {emailTestResult && (
                <div
                  className={`p-4 rounded-lg border ${
                    emailTestResult === "success" ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"
                  }`}
                >
                  <div className="flex items-center">
                    {emailTestResult === "success" ? (
                      <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600 mr-2" />
                    )}
                    <div>
                      <h4
                        className={`text-sm font-medium ${
                          emailTestResult === "success" ? "text-green-800" : "text-red-800"
                        }`}
                      >
                        {emailTestResult === "success" ? "Email sent successfully!" : "Email failed to send"}
                      </h4>
                      <p className={`text-sm ${emailTestResult === "success" ? "text-green-700" : "text-red-700"}`}>
                        {emailTestResult === "success"
                          ? `Check your inbox at ${testEmail}`
                          : "Please check your API configuration"}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
