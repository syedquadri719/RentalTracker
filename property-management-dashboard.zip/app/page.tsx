import Link from "next/link"
import { Home } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <Home className="mx-auto h-16 w-16 text-purple-600 mb-4" />
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">Rental Property Dashboard</h2>
          <p className="mt-2 text-sm text-gray-600">Manage your properties with ease</p>
        </div>
        <div className="mt-8 space-y-4">
          <Link
            href="/dashboard"
            className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-all duration-200 hover:transform hover:-translate-y-1 hover:shadow-lg"
          >
            <Home className="mr-2 h-4 w-4" />
            Go to Dashboard
          </Link>
        </div>
      </div>
    </div>
  )
}
