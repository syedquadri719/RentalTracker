import { pgTable, serial, text, numeric, timestamp, integer, json } from "drizzle-orm/pg-core"

export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  monthly_rent: numeric("monthly_rent", { precision: 10, scale: 2 }).notNull(),
  bedrooms: integer("bedrooms").default(1),
  bathrooms: integer("bathrooms").default(1),
  sqft: integer("sqft"),
  photos: json("photos").default([]),
  created_at: timestamp("created_at").defaultNow().notNull(),
})
